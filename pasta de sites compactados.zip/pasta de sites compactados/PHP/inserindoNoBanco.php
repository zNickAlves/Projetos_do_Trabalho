<?php

include_once ('conexao.php');
$id= $_POST['id'];
$nome= $_POST['nome'];
$cpf= $_POST['cpf'];
$email= $_POST['idade'];
$data= $_POST['data'];

$sql = "INSERT INTO formulario 
 (id,nome,cpf,email,data) VALUES 
 ('$id','$nome','$cpf','$email','$data')"; 
 $query = mysqli_query($conexao, $sql);


?> 
<script>
window.alert('Informações salvas com sucesso!')
window.location.href = "cadastroNoBanco.html";

</script>
<!-- include_once('index.php');        ??index.php é onde fica o log para conexão com o banco
$(nome do type) = $_POST ['Type do input'];

$sql= "INSERT INTO (nome da tabela)
(Nome das colunas) VALUES
('$nome do type')";
$query= mysqli_query($conexao, $sql); -->